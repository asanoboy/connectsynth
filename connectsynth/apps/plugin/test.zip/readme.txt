This set of 50 free scalable Photoshop icons was designed with great care and is intended for use in web and desktop applications.

You may use these icons for both commercial and non-commercial projects and customize them any way you like. Just don't distribute them separately, please.

Designed by Pavel Macek

http://www.matcheck.cz
http://twitter.com/pavel_macek
http://dribbble.com/pavel_macek