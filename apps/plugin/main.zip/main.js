addEventListener('message', onGetWave, false);

function onGetWave(e) {
	var rt = {};

	switch(e.data.action) {
		case 'init':
			wave.setSampleRate(e.data.initParams.sampleRate);
			rt.controller = {
				background : {
					image : "img/background.png",
					height : 300,
					width : 400
				},
				controls : [{
					type : "control",
					name : "val1",
					image : "img/ic_up_circle.png",
					value : 0.5,
					offsetX : 50,
					offsetY : 50,
					width : 32,
					height : 32
				}, {
					type : "toggle",
					name : "val2",
					imageOn : "img/ic_ok.png",
					imageOff : "img/ic_cancel.png",
					value : 0,
					offsetX : 100,
					offsetY : 50,
					width : 32,
					height : 32
				}, {
					type : "radio",
					name : "val3",
					imageOn : "img/ic_ok.png",
					imageOff : "img/ic_cancel.png",
					value : 0,
					offsets : [{
						offsetX : 150,
						offsetY : 50,
					}, {
						offsetX : 150,
						offsetY : 100,
					}, {
						offsetX : 150,
						offsetY : 150,
					}],
					width : 32,
					height : 32
				}],

			};
			break;
		case 'setParam':
			var name = e.data.name;
			var value = e.data.value;
			wave.setParam(name, value);
			break;
		case 'addEvent':
			wave.addEvent(e.data.event);
			break;
		case 'getBuffer':

			var buffer = wave.getBuffer(e.data.length);
			rt.leftBuffer = buffer;
			rt.rightBuffer = new Float32Array(buffer);
			// rt.leftBuffer = new Float32Array(e.data.length);
			// rt.rightBuffer = new Float32Array(e.data.length);
			break;
		default:
			return;
	}

	rt.callback = e.data.callback;

	postMessage(rt);
};

/** @constructor */
var Wave = function(arr, opt_tableSize) {

	this._singingNotes = [];

	/**
	 * 鳴っていたNoteが消えた際の後処理を詰め込んだArray Buffer
	 */
	this._restBuffer = new Float32Array(0);

	this._num = Math.random();

	this._val1 = 0.5;
};
/**
 * @private
 */
Wave.prototype.setSampleRate = function(sampleRate) {
	this._sampleRate = sampleRate;
}

Wave.prototype.addEvent = function(event) {
	switch( event.type ) {
		case 'noteon':
			this._singingNotes.push({
				radianPerSample : event.note.freq / this._sampleRate * 2 * Math.PI,
				note : event.note.note,
				offsetRadian : 0
			});
			break;
		case 'noteoff':
			for(var i = 0; i < this._singingNotes.length; i++) {
				if(this._singingNotes[i].note == event.note.note) {
					this._singingNotes.splice(i, 1);
				}
			}
			break;
		case 'notealloff':
			this._singingNotes = [];
			break;
	}
};

Wave.prototype.setParam = function(name, value) {
	if(name == 'val1') {
		this._val1 = value;
	}
}

Wave.prototype.getBuffer = function(len) {

	var arr = new Float32Array(len);

	for(var i = 0; i < this._singingNotes.length; i++) {
		for(var j = 0; j < len; j++) {
			arr[j] += Math.sin(this._singingNotes[i].radianPerSample * j + this._singingNotes[i].offsetRadian + this._val1 * Math.sin(3 * (this._singingNotes[i].radianPerSample * j + this._singingNotes[i].offsetRadian) + 1.5 * Math.sin(7 * (this._singingNotes[i].radianPerSample * j + this._singingNotes[i].offsetRadian))));
		}
		this._singingNotes[i].offsetRadian += this._singingNotes[i].radianPerSample * len;
	}

	var restLen = len < this._restBuffer.length ? len : this._restBuffer.length;
	for( i = 0; i < restLen; i++) {
		arr[i] += this._restBuffer[i];
	}

	this._restBuffer = this._restBuffer.subarray(restLen);

	return arr;
}
var wave = new Wave([0, 1, 0, -1]);
